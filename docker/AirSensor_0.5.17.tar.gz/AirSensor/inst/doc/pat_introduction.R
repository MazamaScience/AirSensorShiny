## ----setup, include=FALSE, message=FALSE--------------------------------------
knitr::opts_chunk$set(fig.width=7, fig.height=5)
library(MazamaCoreUtils)
library(AirSensor)
library(dplyr)
library(ggplot2)
# NOTE: Use example PAS and PAT data for vignettes to avoid long wait-times
pas <- AirSensor::example_pas
pat <- AirSensor::example_pat

## ----names--------------------------------------------------------------------
pat %>%
  names()

## ----allPlot------------------------------------------------------------------
pat %>%
  pat_multiplot(plottype = "all")

## ----augustPlot---------------------------------------------------------------
pat_august <- 
  pat %>% 
  pat_filterDate(startdate = 20180801, enddate = 20180901)

pat_august %>%
  pat_multiplot(plottype = "pm25_over")

## ----scatterplot, message = FALSE, warning = FALSE----------------------------
  pat_august %>%
    pat_scatterplot()

## ----outlierPlot--------------------------------------------------------------
pat_august_filtered <- 
  pat_august %>%
  pat_outliers(replace = TRUE, showPlot = TRUE)

## ----internalFit, message = FALSE, warning = FALSE----------------------------
one_week <- 
  pat_august %>% 
  pat_filterDate(startdate = 20180813, days = 7)

# Channel A/B comparison
one_week %>% 
  pat_internalFit()

## ----externalFit, message = FALSE, warning = FALSE----------------------------
# Sensor/Monitor comparison
one_week %>% 
  pat_externalFit()

